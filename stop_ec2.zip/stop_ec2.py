import boto3
region = 'eu-west-1'

def lambda_handler(event, context):
    
    #let's use Amazon ec2
    client = boto3.client('ec2', region_name=region)

    #create variable 'response' and save ec2 informations to it using the 'describe_instances()' methode
    response = client.describe_instances()

    #a for loop to browse those informations
    for i in response['Reservations']:
        
        #save the Tags in the variable tags
        tags = (i['Instances'][0]['Tags'])
        #save the ec2 insta ids in the variable instance_id
        instance_id = (i['Instances'][0]['InstanceId'])
        #a for loop to browse dictionaries saved in the variable 'tags'
        for j in tags:
            
            #verify if tags match our condition
            if (j['Value']) == 'day_time':
                
                #stop ec2 instances that match the previous condition using the methode 'stop_instances()'
                client.stop_instances(InstanceIds=[instance_id])